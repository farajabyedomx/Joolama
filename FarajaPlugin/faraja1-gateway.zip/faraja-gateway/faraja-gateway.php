<?php
/*
 * Plugin Name: WooCommerce Faraja Payment Gateway
 * Plugin URI: https://faraja.com
 * Description: Take Faraja Payments on the website.
 * Author: Joseph Nasiire
 * Author URI: https:faraja.com
 * Version: 1.0.1
 */

/*
 * This action hook registers our PHP class as a WooCommerce payment gateway
 */
add_filter( 'woocommerce_payment_gateways', 'faraja_add_gateway_class' );
function faraja_add_gateway_class( $gateways ) {
	$gateways[] = 'WC_Faraja_Gateway'; // your class name is here
	return $gateways;
}

/*
 * The class itself, please note that it is inside plugins_loaded action hook
 */
add_action( 'plugins_loaded', 'faraja_init_gateway_class' );
function faraja_init_gateway_class() {

	class WC_Faraja_Gateway extends WC_Payment_Gateway {

 		/**
 		 * Class constructor, more about it in Step 3
 		 */
 		public function __construct() {
 			$this->id = 'faraja'; // payment gateway plugin ID
			$this->icon = 'http://joolama.com/wp-content/uploads/2021/08/imageedit_1_2822620075.png'; // URL of the icon that will be displayed on checkout page near your gateway name
			$this->has_fields = true; // in case you need a custom credit card form
			$this->method_title = 'Faraja Gateway';
			$this->method_description = 'Description of Faraja payment gateway'; // will be displayed on the options page

			// gateways can support subscriptions, refunds, saved payment methods,
			// but in this tutorial we begin with simple payments
			$this->supports = array(
				'products'
			);

			// Method with all the options fields
			$this->init_form_fields();

			// Load the settings.
			$this->init_settings();
			$this->title = $this->get_option( 'title' );
			$this->description = $this->get_option( 'description' );
			$this->enabled = $this->get_option( 'enabled' );
			$this->testmode = 'yes' === $this->get_option( 'testmode' );
			$this->private_key = $this->testmode ? $this->get_option( 'test_private_key' ) : $this->get_option( 'private_key' );
			$this->publishable_key = $this->testmode ? $this->get_option( 'test_publishable_key' ) : $this->get_option( 'publishable_key' );

			// This action hook saves the settings
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );

			// We need custom JavaScript to obtain a token
			add_action( 'wp_enqueue_scripts', array( $this, 'payment_scripts' ) );

			//$this->fetch_faraja_user();
			//$this->borrowloan();

			
			// You can also register a webhook here
			// add_action( 'woocommerce_api_{webhook name}', array( $this, 'webhook' )

 		}

		/**
 		 * Plugin options, we deal with it in Step 3 too
 		 */
 		public function init_form_fields(){

					$this->form_fields = array(
					'enabled' => array(
						'title'       => 'Enable/Disable',
						'label'       => 'Enable Faraja Gateway',
						'type'        => 'checkbox',
						'description' => '',
						'default'     => 'no'
					),
					'title' => array(
						'title'       => 'Title',
						'type'        => 'text',
						'description' => 'This controls the title which the user sees during checkout.',
						'default'     => 'Faraja Credit',
						'desc_tip'    => true,
					),
					'description' => array(
						'title'       => 'Description',
						'type'        => 'textarea',
						'description' => 'This controls the description which the user sees during checkout.',
						'default'     => 'Pay with your Joolama credit via our super-cool payment gateway.',
					),
					'testmode' => array(
						'title'       => 'Test mode',
						'label'       => 'Enable Test Mode',
						'type'        => 'checkbox',
						'description' => 'Place the payment gateway in test mode using test API keys.',
						'default'     => 'yes',
						'desc_tip'    => true,
					),
					'test_publishable_key' => array(
						'title'       => 'Test Publishable Key',
						'type'        => 'text'
					),
					'test_private_key' => array(
						'title'       => 'Test Private Key',
						'type'        => 'password',
					),
					'publishable_key' => array(
						'title'       => 'Live Publishable Key',
						'type'        => 'text'
					),
					'private_key' => array(
						'title'       => 'Live Private Key',
						'type'        => 'password'
					)
				);	
	 	}

	 	public function buildSuccessResponse(){
	 		$successResponse = array();
			$successResponse ['response']['responseCode'] = 'APPROVED';

			$_SESSION["successResponse"] = $successResponse;
	 	}

	//  	public function connect_to_db($transaction_id){
	//  		try {
	// 			$dbuser = 'joolamauser';
	// 			$dbpass = '!Joolamad3vB1Ed0mx!';
	// 			$host = 'edomx.postgres.database.azure.com';
	// 			$dbname='edomx';
	// 			//$connec = new PDO("pgsql:host=$host;dbname=$dbname", $dbuser, $dbpass);
	// 			$connec = pg_connect("host=$host dbname=$dbname user=$dbuser password=$dbpass")
	//         		or die('Could not connect: ' . pg_last_error());


	// 			}catch (PDOException $e) {
	// 			echo "Error : " . $e->getMessage() . "<br/>";
	// 			die();
	// 			}

	// 			$query = "SELECT * FROM transactions where transaction_id ='". $transaction_id ."' ORDER BY id desc LIMIT 1";

	// //																		'" . $name . "';


	// 		    $result = pg_query($query) or die('Error message: ' . pg_last_error());

	// 		    while ($row = pg_fetch_row($result)) {

	// 		    	global $response;
	// 		    	buildSuccessResponse();


	// 		    	$response = $array();
	// 		    	$response["responseCode"] = "APPROVED";
	// 		    	$json_response = json_encode($response);
	// 		    	//var_dump($json);

	// 		        //print_pre([$transaction_id,$row],true);
	// 		    }

	// 		    pg_free_result($result);
	// 		    pg_close($dbconn);

	// 	    //return($json_response);


	// 		// $sql = 'SELECT * FROM transactions LIMIT 5';

	// 	 //    $result = pg_query($sql) or die('Error message: ' . pg_last_error());

	// 	 //    while ($row = pg_fetch_row($result)) {
 //   //      	var_dump($row);
 //    }

		/**
		 * You will need it if you want your custom credit card form, Step 4 is about it
		 */
		public function payment_fields() {

		// ok, let's display some description before the payment form
				if ( $this->description ) {
					// you can instructions for test mode, I mean test card numbers etc.
					if ( $this->testmode ) {
						$this->description .= ' TEST MODE ENABLED. In test mode, you can use the phone numbers verified on faraja platform.';
						$this->description  = trim( $this->description );
					}
					// display the description with <p> tags etc.
					echo wpautop( wp_kses_post( $this->description ) );
				}

				?>
					<form action="">


					<p class="form-row form-row-wide woocommerce-validated"><br><br>
							<label for="faraja-transaction-number"> 1. Please Enter Your FARAJA Phone Number Below<span class="required">*</span></label><br>
							
							 
							<input id="faraja-transaction-number" class="input-text wc-credit-card-form-transaction-number" type="text" maxlength="20" autocomplete="off" placeholder="xxxxxxxxxx" name="faraja-transaction-number">
							<input type="button" name="submitPhoneButton" value="Send STK Push" onclick="faraja()">

							<?php

								$ordID = $woocommerce->session->order_awaiting_payment; 
								$order_details = wc_get_order( $ordID );
								//$order_price = $order_details->get_total();

								$cart = WC()->cart;
								$cart_price = WC()->cart->total;

						    ?>

							<label > Click on Place order and enter your verification code on the next page</label><br>
					</p>
				</form>
				<script>
					//var authResponseText;
					//var token;
					

					
					//verify user is a faraja user
					function faraja_fetch_user(authToken){
						var authTokens = authToken;
						var phoneNumber = document.getElementById("faraja-transaction-number").value;//user phone number submitted.
						var mode = "&ussd";
						//alert(phoneNumber);

						var url = "https://us-central1-faraja-prod.cloudfunctions.net/fetch/";
						var urlPhone = url.concat(phoneNumber);

						send_url = urlPhone.concat(mode);//url being used for fetch

						//var tokens = faraja_authenticate();

						//alert(send_url);
						//alert(token.value);
						console.log("AUth");
						console.log(authTokens);

						var xhr = new XMLHttpRequest();
						xhr.open("GET", send_url);

						xhr.setRequestHeader("Authorization", "Bearer " + authTokens);

						xhr.onreadystatechange = function () {
						   if (xhr.readyState === 4) {
						      console.log(xhr.status);
						      console.log(xhr.responseText);

						      var fetchResponse = xhr.responseText;
						      var json_customer_status = JSON.parse(fetchResponse);
						      var customer_status = json_customer_status.account_type;
						      console.log("Status");
						      console.log(customer_status);

						      if (customer_status === "qualified_customer") {
						      	console.log("Status = Qualified");
						      	farajaborrow(authTokens, phoneNumber);
						      	console.log("Attempted");
						      }
						      else if (customer_status === "optedin_customer") {
						      	console.log("Status = Opted in but not qualified");
						      }
						   }};

						xhr.send();


					}

					function demoborrow(){
						var url = "https://us-central1-faraja-prod.cloudfunctions.net/termloan";

						var xhr = new XMLHttpRequest();
						xhr.open("POST", url);

						xhr.setRequestHeader("Authorization", "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MjU1NWEyMjM3MWYxMGY0ZTIyZjFhY2U3NjJmYzUwZmYzYmVlMGMiLCJ0eXAiOiJKV1QifQ.eyJwcm92aWRlcl9pZCI6ImFub255bW91cyIsImlzcyI6Imh0dHBzOi8vc2VjdXJldG9rZW4uZ29vZ2xlLmNvbS9mYXJhamEtcHJvZCIsImF1ZCI6ImZhcmFqYS1wcm9kIiwiYXV0aF90aW1lIjoxNjM1NDA5Mjk5LCJ1c2VyX2lkIjoic1ZqZklXTEY2S2hrdkRDN3NhclhvMGpGOXVnMiIsInN1YiI6InNWamZJV0xGNktoa3ZEQzdzYXJYbzBqRjl1ZzIiLCJpYXQiOjE2MzU0MDkyOTksImV4cCI6MTYzNTQxMjg5OSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6e30sInNpZ25faW5fcHJvdmlkZXIiOiJhbm9ueW1vdXMifX0.Uwo295UkWnh3O0gMI-ltG3vJdWtuVim3YTxHrEonMXA_OyVYvOdvXmhONfr3gZHMOuB3Ot8HqfrMhLeh1TpGmg_rdDTYbJz8eypSyXa595H0MT1T12yk_O-Oa2ajaCY5otgYAcHmZQUf1PQnomCRRDylkSuOFvNaMLCrAYbG0q1OPoSfhkIl9A3uD9CHZFrC4dNX8BNI-1rj8CJNEkbgBuedxAG3coe5mKNzMEMq3WWRsHqH1h2HaQyNBOxtWjmGkhtUcOjmAS7nrDFIZIAuovn39b4V9nGegufZFKgZnFXP8LQezdlD61E-ErevK6vaf3t-HzZLZUi9UMDo4r6PAg");
						xhr.setRequestHeader("Content-Type", "application/json");

						xhr.onreadystatechange = function () {
						   if (xhr.readyState === 4) {
						      console.log(xhr.status);
						      console.log(xhr.responseText);
						   }};

						var data = `{
							"mobile_number": "+254757669866",
							"till_number": "5610981",
							"amount": "20",
							"source":"app",
							"token":"sample_firebase_token"
						}`;

						xhr.send(data);

					}

					function farajaborrow(authTokens, customerPhone){
						var borrowAuthToken = authTokens;
						var customerPhoneNumber = customerPhone;


						// console.log("Authtokens = ");
						// console.log(authTokens);

						var url = "https://us-central1-faraja-prod.cloudfunctions.net/termloan";
						var xhr = new XMLHttpRequest();
						xhr.open("POST", url);



						//console.log("broken");

						xhr.setRequestHeader("Authorization", "Bearer " + borrowAuthToken);

						xhr.setRequestHeader("Content-Type", "application/json");

						xhr.onreadystatechange = function () {
						   if (xhr.readyState === 4) {
						      console.log(xhr.status);
						      console.log(xhr.responseText);
						   }};

						   var cartAmount = "<?php echo"$cart_price"?>";

						   console.log(typeof(customerPhoneNumber));

						   let data =	`{"mobile_number":"`+customerPhoneNumber+`","till_number": "9110971","amount": "`+cartAmount+`","source":"USSD","token":""}`;

							// data = JSON.stringify(data);

							 // data = JSON.parse(JSON.parse(data));

						   //str = b.replace(/\\/g, '');

						  data = data.replace(/\\/g, '');

						   console.log(data);

						   //var customerPhoneNumberType = customerPhoneNumber
						   // cartAmount = String(cartAmount);

						//    var data = `{
						// 	mobile_number:"${customerPhoneNumber}",
						// 	till_number: "9110971",
						// 	amount: "${cartAmount}",
						// 	source:"USSD",
						// 	token:""
						// }`;

						//data = JSON.parse(data);

						
						console.log(cartAmount);

						console.log("Data");

						console.log(data);
						//console.log(customerPhoneNumber);
						//console.log(data.mobile_number);
						//console.log(order);

						xhr.send(data);

						console.log("sent");
						console.log(data);



					}

					//authenticate request
					function faraja(){
						var url = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyAq-acX-Bve3p4ZncHTN6u42r60Cl8Ots4";
						

						var xhr = new XMLHttpRequest();
						xhr.open("POST", url);

						xhr.setRequestHeader("Content-Type", "application/json");
						xhr.setRequestHeader("Content-Length", "0");

						xhr.onreadystatechange = function () {
						   if (xhr.readyState === 4) {
						      console.log(xhr.status);
						      console.log(xhr.responseText);
						      authResponseText = xhr.responseText;

						      jsonResponse = JSON.parse(authResponseText);
						      token = jsonResponse.idToken;
						      //console.log(jsonResponse);
						      //console.log(token);
						      //token = authResponseText.idToken;
						      //alert(jsonResponse);
						      //console.log("Token AUth");
					    	  //console.log(token);
						      
						      //alert(xhr.responseText.idToken);
						      //return token;

						      //console.log(token);
						      faraja_fetch_user(token);
						     
						   }};





						xhr.send();


					}



					

					


					

				</script>

				

				<?

				if(isset($_POST['submitPhoneButton'])){
					//var_dump($_POST);
					global $faraja_phone_number;
					$faraja_phone_number = $_POST['faraja-transaction-number'];
					$account_type = $this->fetch_faraja_user($faraja_phone_number);

					//var_dump($account_type);

					//$order = wc_get_order( $_GET['id'] );

					   
					$ordID = $woocommerce->session->order_awaiting_payment; 
					$order_details = wc_get_order( $ordID );
					//$order_price = $order_details->get_total();

					$cart = WC()->cart;
					$cart_price = WC()->cart->total;


					//$amount = $order->get_total();
					//var_dump($cart_price);



					if ($account_type == 'qualified_customer') {
						console.log($account_type);

						$this->borrowloan($faraja_phone_number);
					}
					elseif (account_type == 'optedin_customer') {
						$this->redirectBackToCheckout();
					}
					elseif (account_type=='') {
						$this->redirectToFarajaOptIn();
					}



				}
				
				


			}

			 
			 
			//process fetch 

			

		public function farajaAuth(){
			$url = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyAq-acX-Bve3p4ZncHTN6u42r60Cl8Ots4";

			$curl = curl_init($url);
			curl_setopt($curl, CURLOPT_URL, $url);
			curl_setopt($curl, CURLOPT_POST, true);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

			$headers = array(
			   "Content-Type: application/json",
			   "Content-Length: 0",
			);
			curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
			//for debug only!
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

			$resp = curl_exec($curl);
			curl_close($curl);
			$decodedAuth = json_decode($resp);

			$authkey = $decodedAuth->{'idToken'};


			//var_dump($authkey);

			return($authkey);
		}	

		public function fetch_faraja_user($faraja_phone_number){

			$url = "https://us-central1-faraja-prod.cloudfunctions.net/fetch/";

			$url .= $faraja_phone_number . "&ussd";

			$curl = curl_init($url);
			curl_setopt($curl, CURLOPT_URL, $url);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

			//for debug only!
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

			$resp = curl_exec($curl);
			curl_close($curl);
			$decoded = json_decode($resp);

			$account_type = $decoded->{'account_type'};

			//var_dump($account_type);
			//console.log($account_type);

			return($account_type);


			//var_dump($decoded);

		}
		public function redirectToFarajaConfirmation(){
			header("Location: https://joolama.com/faraja-test-page/");
			exit();
		}
		public function redirectToFarajaOptIn(){
			header("Location: https://www.farajacredit.com/apply-now-for-credit");
			exit();
		}
		public function redirectBackToCheckout(){
			header("Location: https://joolama.com/checkout/");
			exit();
		}

		public function borrowloan($faraja_phone_number){

			global $woocommerce;
					$ordID = $woocommerce->session->order_awaiting_payment; 
					$order_details = wc_get_order( $ordID );
					//$order_price = $order_details->get_total();

					$cart = WC()->cart;
					$cart_price = WC()->cart->total;

			$authorizationKey = $this->farajaAuth();

			$url = "https://us-central1-faraja-prod.cloudfunctions.net/termloan";

			$curl = curl_init($url);
			curl_setopt($curl, CURLOPT_URL, $url);
			curl_setopt($curl, CURLOPT_POST, true);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

			$headers = array(
			   "Authorization: Bearer " . $authorizationKey,
			   "Content-Type: application/json",
			);

			curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

			
	$data = array('mobile_number' => $faraja_phone_number, 'till_number' => 9110971, 'amount' => $cart_price, 'source' => app, 'token' => 'sample_firebase_token');

			$message = json_encode($data);



			 

			curl_setopt($curl, CURLOPT_POSTFIELDS, $message);

			//for debug only!
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

			$resp = curl_exec($curl);
			curl_close($curl);

			//$this->redirectToFarajaConfirmation();

			//var_dump($resp);
		}

		/*
		 * Custom CSS and JS, in most cases required only when you decided to go with a custom credit card form
		 */
	 	public function payment_scripts() {
		// we need JavaScript to process a token only on cart/checkout pages, right?
			if ( ! is_cart() && ! is_checkout() && ! isset( $_GET['pay_for_order'] ) ) {
				return;
			}

			// if our payment gateway is disabled, we do not have to enqueue JS too
			if ( 'no' === $this->enabled ) {
				return;
			}

			// no reason to enqueue JavaScript if API keys are not set
			if ( empty( $this->private_key ) || empty( $this->publishable_key ) ) {
				return;
			}

			// do not work with card detailes without SSL unless your website is in a test mode
			if ( ! $this->testmode && ! is_ssl() ) {
				return;
			}

			// let's suppose it is our payment processor JavaScript that allows to obtain a token
			wp_enqueue_script( 'faraja_js', 'https://www.farajapayments.com/api/token.js' );

			// and this is our custom JS in your plugin directory that works with token.js
			wp_register_script( 'woocommerce_faraja', plugins_url( 'faraja.js', __FILE__ ), array( 'jquery', 'faraja_js' ) );

			// in most payment processors you have to use PUBLIC KEY to obtain a token
			wp_localize_script( 'woocommerce_faraja', 'faraja_params', array(
				'publishableKey' => $this->publishable_key
			) );


			wp_enqueue_script( 'woocommerce_faraja' );

			
	 	}

		/*
 		 * Fields validation, more in Step 5
		 */
		/*public function validate_fields() {

		...

		}
		*/

		/*
		 * We're processing the payments here, everything about it is in Step 5
		 */
		
		
		public function change_payment_complete_order_status( $status, $order_id = 0, $order = false ) {
			
			if ( $order && 'cod' === $order->get_payment_method() ) {
				$status = 'Awaiting Faraja Confirmation';
			}
			
			return $status;
		}



		public function process_payment( $order_id ) {
			

				global $woocommerce;


			$order = wc_get_order( $order_id );

			if ( $order->get_total() > 0 ) {
				// Mark as processing or on-hold (payment won't be taken until delivery).
				$order->update_status( apply_filters( 'woocommerce_cod_process_payment_order_status', $order->has_downloadable_item() ? 'on-hold' : 'pending-payment', $order ), __( 'Faraja Payment.', 'woocommerce' ) );
			} else {
				$order->payment_complete();
			}

			// Remove cart.
			WC()->cart->empty_cart();

			// Return thankyou redirect.
			return array(
				'result'   => 'success',
				'redirect' => $this->get_return_url( $order ),
			);
 
				// we need it to get any order detailes
				// $order = new WC_Order( $order_id );
				// $order = wc_get_order( $order_id );
			 
			 
				// /*
			 // 	 * Array with parameters for API interaction
				//  */
				
				// /*
				//  * Your API interaction could be built with wp_remote_post()
			 // 	 */
				//  //$response = wp_remote_post( '{payment processor endpoint}', $args );
				//  $response = $_SESSION["successResponse"];
				//  var_dump($response);
	
			 
				//  if( !is_wp_error( $response ) ) {
			 
				// 	 $body = json_decode( $response['response'], true );
				// 	 //var_dump($body);
			 
				// 	 // it could be different depending on your payment processor
				// 	 if ( $body['response']['responseCode'] == 'APPROVED' ) {
			 
				// 		// we received the payment
				// 		$order->payment_complete();
				// 		$order->reduce_order_stock();
			 
				// 		// some notes to customer (replace true with false to make it private)
				// 		$order->add_order_note( 'Hey, your order is paid! Thank you!', true );
			 
				// 		// Empty cart
				// 		$woocommerce->cart->empty_cart();
			 
				// 		// Redirect to the thank you page
				// 		return array(
				// 			'result' => 'success',
				// 			'redirect' => $this->get_return_url( $order )
				// 		);
			 
				// 	 } else {
				// 		wc_add_notice(  'Please try again.', 'error' );
				// 		//var_dump($body);
				// 		return;
				// 	}
			 
				// } else {
				// 	wc_add_notice(  'Connection error.', 'error' );
				// 	return;
				// }
			 
		
					
	 	}

		/*
		 * In case you need a webhook, like PayPal IPN etc
		 
		public function webhook() {

		...
					
	 	}*/
 	}
}


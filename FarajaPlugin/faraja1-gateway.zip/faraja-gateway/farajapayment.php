<?php

get_header();
$sidebar_configs = diza_tbay_get_page_layout_configs();

$class_row = ( get_post_meta( $post->ID, 'tbay_page_layout', true ) === 'main-right' ) ? 'flex-row-reverse' : '';

diza_tbay_render_breadcrumbs();



function suceesfulpayment(){
// we received the payment

	$ordID = $woocommerce->session->order_awaiting_payment; 
	$order_details = wc_get_order( $ordID );
	$order_price = $order_details->get_total();

	$cart = WC()->cart;
	$cart_price = WC()->cart->total;	
	$order_details->payment_complete();
	$order->reduce_order_stock();
 
			// // some notes to customer (replace true with false to make it private)
			// $order->add_order_note( 'Hey, your order is paid! Thank you!', true );
 
			// // Empty cart
	$woocommerce->cart->empty_cart();

}


function buildSuccessResponse(){
	$successResponse = array();
	$successResponse ['response']['responseCode'] = 'APPROVED';

	$_SESSION["successResponse"] = $successResponse;

	//header("Location: https://joolama.com/checkout/");
	//exit();
	redirectToFarajaCheckout();

	//var_dump($_SESSION["successResponse"]);
}

function redirectToFarajaCheckout(){

	echo("<script>location.href = 'https://joolama.com/checkout/';</script>");


		// error_reporting(E_ALL | E_WARNING | E_NOTICE);
		// ini_set('display_errors', TRUE);
		// flush();
		// header("Location:https://joolama.com/checkout/");
		// die('should have redirected by now');
	}


			 

if(isset($_POST['submitButton'])){
				global $faraja_transaction_number;
				$faraja_transaction_number = $_POST['faraja-transaction-number'];
				//var_dump($faraja_transaction_number);
				connect_to_db($faraja_transaction_number);
				//getCartDataFromSession();
				
			}

function print_pre($array, $exit = false, $_FILE_ = NULL, $_LINE_ = NULL, $_METHOD_ = NULL)
    {
        echo "<pre>";
        echo $_FILE_ . '<br>';
        if (is_array($array)) {
            echo "<hr>";
            echo "Records \t:" . (count($array, 0));
            echo "<br>";
            echo "Data \t\t:" . (count($array, 1));

            echo "<hr>";
        } else {
            strlen($array);
        }
        print_r($array);
        echo $_FILE_ . '<br>';
        echo $_LINE_ . '<br>';
        echo $_METHOD_ . '<br>';


        if ($exit) {
            exit("</pre>");
        } else {
            echo "</pre>";
        }
    
}

//transaction_id

function getCartDataFromSession(){
	global $woocommerce;
	//var_dump($woocommerce->cart);

	$ordID = $woocommerce->session->order_awaiting_payment; 

	var_dump($ordID);




	//$order->payment_complete();
	//$order->reduce_order_stock();

	// some notes to customer (replace true with false to make it private)
	//$order->add_order_note( 'Hey, your order is paid! Thank you!', true );

	// Empty cart
	//$woocommerce->cart->empty_cart();
}


 function connect_to_db($transaction_id){
 	try {
			$dbuser = 'joolamauser';
			$dbpass = '!Joolamad3vB1Ed0mx!';
			$host = 'edomx.postgres.database.azure.com';
			$dbname='edomx';
			//$connec = new PDO("pgsql:host=$host;dbname=$dbname", $dbuser, $dbpass);
			$connec = pg_connect("host=$host dbname=$dbname user=$dbuser password=$dbpass")
        		or die('Could not connect: ' . pg_last_error());


			}catch (PDOException $e) {
			echo "Error : " . $e->getMessage() . "<br/>";
			die();
			}

			$query = "SELECT * FROM transactions where transaction_id ='". $transaction_id ."' ORDER BY id desc LIMIT 1";

//																		'" . $name . "';


		    $result = pg_query($query) or die('Error message: ' . pg_last_error());

		    while ($row = pg_fetch_row($result)) {
		    	buildSuccessResponse();


		    	//$response = $array();
		    	//$response["responseCode"] = "APPROVED";
		    	//$json_response = json_encode($response);

		        //print_pre([$transaction_id,$row],true);
		    }

		    pg_free_result($result);
		    pg_close($dbconn);


			// $sql = 'SELECT * FROM transactions LIMIT 5';

		 //    $result = pg_query($sql) or die('Error message: ' . pg_last_error());

		 //    while ($row = pg_fetch_row($result)) {
   //      	var_dump($row);
    }

					
 


// function connect_to_db(){
// 				$servername = "edomx.postgres.database.azure.com:5432";
// 				$username = "joolamauser";
// 				$password = "!Joolamad3vB1Ed0mx!";

// 				// Create connection

// 				$conn = new pg_connect($servername, $username, $password);


// 				// Check connection
// 				if ($conn->connect_error) {
// 				  die("Connection failed: " . $conn->connect_error);
// 				}
// 				echo "Connected successfully";

// 				//$sql = "SELECT * FROM transactions LIMIT 5";
// 				//$result = $conn->query($sql);

// 				//var_dump($result);


// 			}


?>

<section id="main-container" class="<?php echo apply_filters('diza_tbay_page_content_class', 'container');?>">
	<div class="row <?php echo esc_attr($class_row); ?>">
		<?php if ( isset($sidebar_configs['sidebar']) && is_active_sidebar($sidebar_configs['sidebar']['id']) ) : ?>
		<div class="<?php echo esc_attr($sidebar_configs['sidebar']['class']) ;?>">
		  	<aside class="sidebar" itemscope="itemscope" itemtype="http://schema.org/WPSideBar">
		   		<?php dynamic_sidebar( $sidebar_configs['sidebar']['id'] ); ?>
		  	</aside>
		</div>
		<?php endif; ?>
		<div id="main-content" class="main-page <?php echo esc_attr($sidebar_configs['main']['class']); ?>">
			<div id="main" class="site-main">

				<?php 
					diza_tbay_render_title();
				?>

				<?php
				// Start the loop.
				while ( have_posts() ) : the_post();
				
					// Include the page content template.
					the_content(); 
 
					// If comments are open or we have at least one comment, load up the comment template.
					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;

				// End the loop.
				endwhile;
				?>
			</div><!-- .site-main -->



			
			<center>
			<img src="https://joolama.com/wp-content/uploads/2021/08/imageedit_1_2822620075.png"><br>
				<form action="" method="post">
					<p class="form-row form-row-wide woocommerce-validated"><br><br>
							<label for="faraja-transaction-number">Please Enter Your FARAJA Confirmation Code Below<span class="required">*</span></label><br>
							
							 
							<input id="faraja-transaction-number" class="input-text wc-credit-card-form-transaction-number" type="text" maxlength="20" autocomplete="off" placeholder="xxxxxxxxxx" name="faraja-transaction-number">
							<input type="submit" name="submitButton">
					</p>
				</form>
			</center>
			<?

			

			
			?>
		


		</div><!-- .content-area -->
	</div>
</section>
<?php get_footer(); ?>